﻿<?
use RightNow\Connect\v1_3 as RNCPHP;
    try
    {
        $sessionId = $_GET['p_id'];//agent Session

        // Set up and call the AgentAuthenticator
        require_once (get_cfg_var('doc_root') . '/include/services/AgentAuthenticator.phph');

        $account = AgentAuthenticator::authenticateSessionID($sessionId);
        if (!isset($account))
        {
            throw new \Exception("Couldn't Authenticate Agent using Session ID");
        }	        
		$sessionToken = getArcGisToken();
		$serverURL = RNCPHP\Configuration::fetch(CUSTOM_CFG_ESRI_SERVER_URL)->Value;
		$featureLayers = getGISFeatureLayers();
    }
    catch(\Exception $ex)
    {
         echo  $ex->getMessage();
    }
    catch (RNCPHP\ConnectAPIErrorBase $e) {
    	echo $e->getMessage();
	}    

	function getGISFeatureLayers()
    {
		try
		{
			//Get all feature layers
			$featureLayers = array();
			$query = "SELECT LayerName, LayerAPI, UsedInSearchWidget, SearchField FROM Config.FeatureLayer WHERE LayerName = 'locator'";
			$records = RNCPHP\ROQL::query($query)->next();
			while($record = $records->next())
			{
				$featureLayers[$record["LayerName"]] = array("API"=>$record["LayerAPI"], "UsedInSearchWidget"=>$record["UsedInSearchWidget"], "SearchField"=>$record["SearchField"]);
			}		
			return $featureLayers;
		}
		catch ( RNCPHP\ConnectAPIErrorBase $e )
		{
			errorLog("Error in getGISFeatureLayers. Error is: ". $e->getMessage() );
		}
		catch(Exception $e ) {
			errorLog( "Error in getGISFeatureLayers. Error is: ". $e->getMessage() );
		}
		return NULL;
    }

	function getArcGisToken()
    {
    	try
    	{
			$referer = RNCPHP\Configuration::fetch(CUSTOM_CFG_OSVC_URL)->Value;
			$uname = RNCPHP\Configuration::fetch(CUSTOM_CFG_ESRI_USERNAME)->Value;
			$pwd = RNCPHP\Configuration::fetch(CUSTOM_CFG_ESRI_PASSWORD)->Value;
			$tokenURL = RNCPHP\Configuration::fetch(CUSTOM_CFG_ESRI_GENERATE_TOKEN)->Value;
			$crtBundleLoc = RNCPHP\Configuration::fetch(CUSTOM_CFG_CA_CRT_BUNDLE_LOCATION)->Value;
			//$radius = RNCPHP\Configuration::fetch(CUSTOM_CFG_ESRI_SEARCH_RADIUS)->Value;

			load_curl();
			$curl = curl_init();
			curl_setopt_array($curl, array(
				//GISPARAMETER
				CURLOPT_URL => $tokenURL,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_SSL_VERIFYPEER => 1,
				CURLOPT_SSL_VERIFYHOST => 2,
				CURLOPT_CAINFO => '/cgi-bin/' . cfg_get((120)) . '.db'.$crtBundleLoc,  
				
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS => "username=".$uname."&password=".$pwd."&f=JSON&expiration=120&client=referer&referer=".$referer,
				CURLOPT_HTTPHEADER => array(
					"Content-Type: application/x-www-form-urlencoded"
				)
			));	
		
			$response = curl_exec($curl);
			$response = json_decode($response, true);
			$error = curl_error( $curl );
			$code = curl_getinfo($curl, CURLINFO_HTTP_CODE);			
			curl_close($curl);
			if( $code == 200 && !$response["error"])
			{			
				return $response["token"];
			}
			else
			{
				errorLog("Curl Code: ". $code);
				errorLog("Error: ". $error);
				errorLog("Response : ". print_r($response,true));
			}		
		}
		catch ( RNCPHP\ConnectAPIErrorBase $e )
		{
			errorLog("Error in getArcGisToken. Error is: ". $e->getMessage() );
		}
		catch(Exception $e ) {
			errorLog( "Error in getArcGisToken. Error is: ". $e->getMessage() );
		}
		return NULL;
    }

?>

<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge" >
  <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">

  <style>
    html, body {
      padding: 0;
      margin: 0;
      height: 100%;
      width: 100%;
      overflow-x:hidden;
      
    }
	.esri-search
	{
		width: 95% !important;
	}
	.esri-search--show-suggestions .esri-search__suggestions-menu, .esri-search--sources .esri-search__sources-menu {
	    overflow: scroll !important;
	    visibility: visible;
	    max-height: 90px !important;
	    animation: esri-fade-in 250ms ease-out;
	}	
	.esri_map_only
	{
		height:98%;
		border: 1px solid black;
	}
	.esri_map
	{
		height:58%;
		border: 1px solid black;
	}
	
	.rn_PageContent {
		padding-top: 2em;
	}
    .esri-search__input{
		margin-bottom:0 !important;
	}
	.esri-menu__header{
		display: none !important;
	}
	.esri-search__sources-button{
		display: none !important;
	}
	.esri-search__suggestions-list{	
		border-top: solid 1px rgba(110,110,110,0.3);
	    border-top-width: 1px;
	    border-top-style: solid;
	    border-top-color: rgba(110, 110, 110, 0.3);
	    border-top-width: 1px;
	    border-top-style: solid;
	    border-top-color: rgba(110, 110, 110, 0.3);
	}
	.esri-view-height-less-than-medium .esri-popup__main-container {
		max-height: 150px !important;
	}
  </style>
  <link rel="stylesheet" href="https://js.arcgis.com/4.20/esri/themes/light/main.css">
  <script src="https://js.arcgis.com/4.20/"></script>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <script>  
	//GISPARAMETER - Geocode Server	& Custom Search Options	
    require([
      "esri/widgets/Search/LocatorSearchSource",
      "esri/tasks/Locator",
      "esri/widgets/Search",
      "esri/request",
	  "esri/identity/IdentityManager"
    ], function(LocatorSearchSource, Locator, Search, esriRequest, IdentityManager) 
    {     
		//GISPARAMETER - REST/SERVICES
    	let serverURL ="<?php echo $serverURL; ?>";
    	let token = "<?php echo $sessionToken; ?>";

				/****** Add Authentication ******/
		IdentityManager.registerToken({
				'server': serverURL,
				'token': token
			});
		/****** End of Add Authentication ******/

		var featureLayers = <?php echo json_encode($featureLayers); ?>;
    	let locatorURL = featureLayers.locator.API;

				
		/****** Add Custom Search ******/
			var customSearchSource = new LocatorSearchSource({
				locator: new Locator({ url: locatorURL }),
				getSuggestions: function (params) {
					// You can request data from a
					// third-party source to find some
					// suggestions with provided suggestTerm
					// the user types in the Search widget
					return esriRequest(locatorURL + "/findAddressCandidates", {
						query: {
							SingleLine: params.suggestTerm.replace(/ /g, " "),
							limit: 6,
							f:'pjson'
						},
						responseType: "json"
					}).then(function (results) {
						// Return Suggestion results to display
						// in the Search widget
						return results.data.candidates.map(function (candidate) {
							return {
								key: "name",
								text: candidate.address,
								sourceIndex: params.sourceIndex
							};
						});
					});
				},
				getResults: (params) => {
					setWsFields(params.suggestResult.text);
				},
				singleLineFieldName: "SingleLine",
				name: "Custom Geocoding Service",
				placeholder: "Search Geocoder",
				maxResults: 3,
				maxSuggestions: 6,
				suggestionsEnabled: true,
				minSuggestCharacters: 0//,
				//withinViewEnabled:true
			});
		
		
			var search = new Search({
				container:"searchDiv",
				sources: [customSearchSource],
				includeDefaultSources: false							
			});
			
		/****** End of Add Custom Search ******/	
				
  		
    });
    
    var c = window.external.Contact;
    var addressModified = false; // Flag to store if Map was used to fetch the address.
	//If opened through Destop Console then use Javascript Extension
	if(c !== undefined)
	{
	}
	else
	{
		var theWorkspaceRecord;
		var script = document.createElement('script');                
		script.type = 'text/javascript';
		script.async = true;
		script.src = '/AgentWeb/module/extensibility/js/client/core/extension_loader.js';	
		script.onload = function() {			
			ORACLE_SERVICE_CLOUD.extension_loader.load("AddressValidationExtionsion", "1")
			.then(function(extensionProvider)
			{
		    	extensionProvider.registerWorkspaceExtension(function(workspaceRecord)
		    	{
	    			theWorkspaceRecord = workspaceRecord;    			   
		    	});
			});
		};	
		document.head.appendChild(script);				
			
		function setWsFields(address)
		{
			let adrInfo = address.trim().split(",");
			let postalCode =' ';
			let city = '';
			let unitNum = '';
			
			if(adrInfo.length == 2)
			{	
				city = adrInfo[1].trim();//ex: Sudbury
			}
			else if(adrInfo.length == 3)
			{
				postalCode = adrInfo[2].trim();			
				city = adrInfo[1].trim();//ex: Sudbury
			}
			else if(adrInfo.length == 4)
			{
				postalCode = adrInfo[3].trim();			
				city = adrInfo[2].trim();//ex: Sudbury		
				unitNum = adrInfo[1].trim().split(' ')[1].trim();//Unit 3..get #	
			}
			
			let streetInfo = adrInfo[0].trim().split(" ");			
			let houseNumber = streetInfo[0].trim();// ex: "23"
			let streetName = "";			

			if(typeof streetInfo[1] === 'number' || streetInfo[1].length == 1)//Check if unit number if provided, it will either in interger or A-Z
			{
				houseNumber = houseNumber +' '+streetInfo[1].trim();
				streetName = streetInfo.slice(2, streetInfo.length).join(" ");			
			}
			else
			{
				streetName = streetInfo.slice(1, streetInfo.length).join(" ");
			}
	        let recordType = theWorkspaceRecord.getWorkspaceRecordType();
			if(recordType == 'Contact')
			{
				recordType = recordType + '.CO$';				
				theWorkspaceRecord.updateFieldByLabel(recordType+'State', 'Ontario');
				theWorkspaceRecord.updateFieldByLabel(recordType+'Country', 'CA');	
				
			}
			else//case of custom object CO$Address
				recordType = recordType + '.';
				
			// Set the fields in Service Cloud/B2C. 
			theWorkspaceRecord.updateField(recordType+'HouseNumber', houseNumber);
			theWorkspaceRecord.updateField(recordType+'StreetName', streetName);
			theWorkspaceRecord.updateField(recordType+'City', city);
			theWorkspaceRecord.updateField(recordType+'PostalCode', postalCode);
			theWorkspaceRecord.updateField(recordType+'Unit', unitNum);			
		}
	}
  </script>
    
  </head>
<body>
  <div id="searchDiv" style="border: 1px solid black;"></div>
 
</body>
<script>
	/*
	Configure observation of ArcGIS to handle the 'renderNoResultsWarning'function
	This function creates a warning message that says no results have been found even
	if they were. This is rendered from the search when no *exact* results have been found.

	If there were a new property, if the layer wasn't exact, or for any other reason,
	this could be shown be misleading:
	therefor -> observe the dom object and update to a proper message.
	
	Attempted to overload the search.renderNoResultsWarning, update Search.messages
	to no avail. This is simplest.
	*/

	// Options for the esri observer
	const config = { attributes: true, childList: true, subtree: true };

	// Callback function for when esri warning div is modified
	const callback = (mutationList, observer) => {
		for (const mutation of mutationList) {
			if (mutation.type === "childList") {
				// take copy of the text in the warning div
				let warningText = mutation.target.lastChild.textContent;
				if(warningText.includes("There were no results found for")){
					// remove the header
					mutation.target.parentNode.firstChild.textContent = "";

					const textCommaCount = (warningText.split(",").length - 1);
					// one comma, update warning div
					if (textCommaCount == 1){
						mutation.target.textContent = warningText.replace("There were no results found for", "There were no exact matches found for").concat(" Ensure this is accurate.");
						const warningHeader = mutation.target.parentNode.firstChild.textContent;
						mutation.target.parentNode.firstChild.textContent = warningHeader.replace("No results", "No exact match");
					}
					// two commas, likely an actual match, show no warning text
					else if (textCommaCount == 2){
						mutation.target.textContent = "";
						//mutation.target.parentNode.firstChild.textContent = "";
					}
				}
			}
		}
	};

	// Create an observer instance linked to the callback function
	const observer = new MutationObserver(callback);

	//create flag for determining if observing is occuring
	let observingFlag = false;

	// Create a wrapper mutation observer, that watches the entire body
	// Within the wrapper observer, wait for the esri warning div to be visible
	new MutationObserver((mutationList) => {
		// Select list of nodes that match the esri class
		const targetNodes = document.getElementsByClassName('esri-search__warning-text');
		if (targetNodes.length == 1) {
			// not currently observing, attach observer to warning div
			// flag used to prevent multiple observations of the same div
			if(observingFlag == false){
				// A single Esri warning div exists
				// Start observing the target node for configured mutations
				observingFlag = true;
				observer.observe(targetNodes[0], config);
			}
		}
		else{
			observingFlag = false;
			observer.disconnect();
		}
	})
	.observe(document.body, { childList: true, subtree: true })
</script>
</html>
