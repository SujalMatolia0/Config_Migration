﻿<?php
use RightNow\Connect\v1_4 as RNCPHP,
Custom\Libraries\Environment as Environment;
    try
    {
        $session_id = $_GET['p_id'];//agent Session

        // Set up and call the AgentAuthenticator
        require_once (get_cfg_var('doc_root') . '/include/services/AgentAuthenticator.phph');

        $account = AgentAuthenticator::authenticateSessionID($session_id);
        if (!isset($account))
        {
            throw new \Exception("Couldn't Authenticate Agent using Session ID");
        }		
        
        $context = RNCPHP\ConnectAPI::getCurrentContext();
		$context->ApplicationContext = "Get Account w session id";
        $agentObj = RNCPHP\Account::fetch((int) $account['acct_id']);
         
        $agentName = $agentObj->LookupName;
		
    }
    catch(\Exception $ex)
    {
         echo  $ex->getMessage();
    }
    catch (RNCPHP\ConnectAPIErrorBase $e) {
    	echo $e->getMessage();
	}
?>
<!DOCTYPE html> 
<meta http-equiv="X-UA-Compatible" content="IE=Edge" >
<script>
	var theWorkspaceRecord;
	var script = document.createElement('script');                
	script.type = 'text/javascript';
	script.async = true;
	script.src = '/AgentWeb/module/extensibility/js/client/core/extension_loader.js';	
	script.onload = function() {
			
		ORACLE_SERVICE_CLOUD.extension_loader.load("LoggedInAccount", "1")
		.then(function(extensionProvider)
		{
				
		    namedLogger = extensionProvider.getLogger('CGS Logger');
		    namedLogger.trace('Load CGS Logged In Account');
		
		    extensionProvider.registerWorkspaceExtension(function(workspaceRecord)
		    {

	    		theWorkspaceRecord = workspaceRecord;
				//List of fields to be prefetch
				workspaceRecord.prefetchWorkspaceFields(['Incident.c$closing_notes','Incident.CO$ClosingNotesUpdatedByUser']);
	    			
				//OOTB Workspace Event
				workspaceRecord.addRecordSavingListener(dataSavingListenerForSR);
	                
		    });
		});
	};	
	document.head.appendChild(script);			
		
	//Function to call custom form validation on save operation of Incident
	//If custom form validation fails then cancel the save operation		
	function dataSavingListenerForSR(parameter) {		
		if (parameter.event.fieldObjects["Incident.c$closing_notes"].value)
		{
			if(parameter.event.fieldObjects["Incident.c$closing_notes"].value.length >= 10)
			{
				theWorkspaceRecord.updateField('Incident.CO$ClosingNotesUpdatedByUser', "<?php echo $agentName  ?>");
			}
			else 
			{
				parameter.getCurrentEvent().cancel();
				alert("Please enter a longer closing note.");
			}
		}
	}		
</script>
<body>
</body>