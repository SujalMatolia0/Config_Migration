﻿<?
// Find our position in the file tree
if (!defined('DOCROOT')) {
	$docroot = get_cfg_var('doc_root');
	define('DOCROOT', $docroot);
}

/************* Agent Authentication ***************/

// Set up and call the AgentAuthenticator
require_once(DOCROOT . '/include/services/AgentAuthenticator.phph');

// On failure, this includes the Access Denied page and then exits,
// preventing the rest of the page from running.
$account = AgentAuthenticator::authenticateSessionID($_POST['sessiontoken']);

/************* End agent authentication ***********/

// Set up versioned namespace for the Connect PHP API

use RightNow\Connect\v1_3 as RNCPHP;

initConnectAPI();

	try{
		//Data, connection, auth
		load_curl();
		$account = RNCPHP\Account::fetch($_POST['acctid']);
		$agent_extension = $account->CustomFields->CO->agent_extension;
		$url = RNCPHP\Configuration::fetch(CUSTOM_CFG_ACTIVECALL_API_URL)->Value;
		$key = RNCPHP\Configuration::fetch(CUSTOM_CFG_ACTIVECALL_API_KEY)->Value;
		$array = array("Key" => $key,"Extension" => $agent_extension);

		$json = json_encode($array, 128);
		//$url = "http://209.91.135.228/api/listactivecalls/";
		load_curl();
		$curl = curl_init();
		curl_setopt_array($curl, array(
									CURLOPT_URL => $url,
									CURLOPT_RETURNTRANSFER => true,
									CURLOPT_POST=>1,
									CURLOPT_TIMEOUT=> 21,
									CURLOPT_SSL_VERIFYPEER => 0,
									CURLOPT_SSL_VERIFYHOST => 0,								
									CURLOPT_POSTFIELDS=> $json,			
									CURLOPT_CUSTOMREQUEST => "POST",
									CURLOPT_HTTPHEADER => array(
															'Accept: application/json',
															'Content-Type: application/json'
														)
		));
		
		$result = curl_exec($curl);
		$error = curl_error( $curl );
		curl_close($curl);
		if($result)
		{
			$responsearr = json_decode($result);
			$arr = array();
			if($responsearr->Status == "OK" && isset($responsearr->CallerNumber))
			{
				$arr['Status'] = $responsearr->Status;
				$arr['CallID'] = $responsearr->CallID;
				$arr['CallerName'] = $responsearr->CallerName;
				$arr['CallerNumber'] = $responsearr->CallerNumber;
				$arr['DailedNumber'] = $responsearr->DailedNumber;
				$arr['ivrOption'] = $responsearr->IVROption;
				$arr['agent_extension'] = $agent_extension;

				if($responsearr->CallerNumber == $agent_extension || $responsearr->DailedNumber == $agent_extension || $responsearr->IVROption == $agent_extension)
				{
					$arr['Status'] = "FAIL";
					$arr['Reason'] = "No data returned";
				}
				else
				{
					$arr['Status'] = "OK";
					$arr['Calls']['CallID'] = $responsearr->CallID;
					$arr['Calls']['SourceNumber'] = $responsearr->CallerNumber;
				}
			}
			else{
				$arr['Status'] = "FAIL";
				$arr['Reason'] = "No data returned";
			}
			echo ltrim(json_encode($arr));
		}
		else{
			$arr['Status'] = "FAIL";
			$arr['Reason'] = "Error in Service";
		}
					
	}
	catch (Exception $ex) {
		echo $ex->getMessage();		
	}	


