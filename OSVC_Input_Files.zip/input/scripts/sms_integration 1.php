﻿<?php
use RightNow\Connect\v1_3 as RNCPHP;
require_once (get_cfg_var('doc_root') . '/include/services/AgentAuthenticator.phph');

//user integration credentials
$integration_username = 'api_RNT';
$integration_password = 'Welcome@2020';

//authenticate user with integration credentials
$account = AgentAuthenticator::authenticateCredentials($integration_username, $integration_password);
if (!isset($account))
{
	throw new \Exception("Couldn't Authenticate Agent using credentials");
}

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Max-Age: 1000');
header('Content-Type: text/xml');

//get XML POST data
$msg = file_get_contents('php://input');

//Parse XML	
$p = xml_parser_create();
xml_parser_set_option( $p, XML_OPTION_CASE_FOLDING, 0 );
xml_parser_set_option( $p, XML_OPTION_SKIP_WHITE, 1 );
xml_parse_into_struct( $p, $msg, $tags );
xml_parser_free( $p );

$msgID = '';
$from = '';
$content = '';
$receivedOnGroup='';
$infoLog = "";
foreach ($tags as $tag) 
{
	if( $tag['tag']=="deliverRequest")
	{
		$msgID = tag['attributes']['id'];
	}
	elseif( $tag['tag']=="from")
	{
		$from = explode('+',$tag['value'])[1];//avoid +
	}	
	elseif( $tag['tag']=="content")
	{
		$content = strtoupper(trim($tag['value']));
	}
	elseif( $tag['tag']=="receivedOnGroup")
	{
		$receivedOnGroup = $tag['attributes']['value'];
	}						
}

$infoLog .= "Content ". $content." recieved from ".$from." via ".$receivedOnGroup." mobile network".PHP_EOL;
	
switch($content)
{
	case "YES":
	case "OUI":
		//Get OSvC contact by mobile number, if found then update and send respond back accordingly
		$contact = getContact($from);		
		if($contact)
		{
			$lang = "SmsContentInEnglish";//By Default
			if($contact->CustomFields->c->preferredlang->LookupName == 'French')
				$lang = "SmsContentInFrench";
			
			$infoLog .= "Preferred Lang: ".$lang.PHP_EOL;				
			$infoLog .= "Contact ID: ".$contact->ID." found in OSvC".PHP_EOL;
				
			updateContact($contact, 'YES', $receivedOnGroup);
			sendSMS($from, $receivedOnGroup, $lang, 'SUCCESSFULLY_SUBSCRIBED');	
		}			
		break;
	case "INFO":
		sendSMS($from, $receivedOnGroup, 'SmsContentInEnglish', 'INFO');			
		break;
	case "HELP":
		sendSMS($from, $receivedOnGroup, 'SmsContentInEnglish', 'HELP');			
		break;	
	case "AIDE":
		sendSMS($from, $receivedOnGroup, 'SmsContentInFrench', 'HELP');			
		break;
	case "STOP":
	case "ARRET":
		// send respond back 	
		$lang = "SmsContentInEnglish";//By Default
		if($content == 'ARRET')
			$lang = "SmsContentInFrench";		
		sendSMS($from, $receivedOnGroup, $lang, 'STOP');
		//Get OSvC contact by mobile number, if found then update 	
		$contact = getContact($from);	
		if($contact)
		{	
			updateContact($contact, 'NO', $receivedOnGroup);				
		}					
		break;		
}

//Log the info
errorLog($infoLog);


/*
Get OSvC contact based on mobile number from which sms is recieved
Make sure OSvC contact has right opt in
*/
function getContact($mNum)
{
	try
	{
		$mNumWithOutC = ltrim($mNum,'1');//remove country code
		//Get the SMS content
		//AND MarketingSettings.MarketingOptIn = 1 AND CustomFields.c.preferred_notification_method.LookupName='SMS Text Messaging'
		$query = "SELECT Contact FROM Contact WHERE (Phones.PhoneList.Rawnumber = '".$mNum."' OR Phones.PhoneList.Rawnumber = '".$mNumWithOutC."') AND phones.phonelist.phonetype.lookupname ='Mobile Phone' ";
		$contact = RNCPHP\ROQL::queryObject($query)->next()->next();
	}
	catch ( RNCPHP\ConnectAPIErrorBase $e )
	{
		errorLog("Error in getContact for Mobile Numer: ".$mNum.". Error is: ". $e->getMessage() );
	}
	catch(Exception $e ) {
		errorLog( "Error in getContact for Mobile Numer: ".$mNum.". Error is: ".$e->getMessage() );
	}
	return $contact;
}
/*
Update OSvC contact with SMS Opt In info and Mobile Network information
*/
function updateContact($contact, $optIn, $mNetwork)
{
	try
	{
		$contact->CustomFields->c->mobile_network = $mNetwork;
		if($optIn == 'YES')
		{
			$contact->CustomFields->c->sms_opt_in = true;		
			$f_count = count($contact->Notes);
			if($f_count == 0)
				$contact->Notes= new RNCPHP\NoteArray();
			$contact->Notes[$f_count] = new RNCPHP\Note();
			//$contact->Notes[$f_count]->Channel = new RNCPHP\NamedIDLabel();
			//$contact->Notes[$f_count]->Channel->LookupName = "Phone";
			$contact->Notes[$f_count]->Text = "SMS OPT IN";			
		}
		else
		{
			$contact->CustomFields->c->notification_opt_in = false;
			$contact->CustomFields->c->sms_opt_in = false;			
			$contact->CustomFields->c->preferred_notification_method = NULL;	
			$f_count = count($contact->Notes);
			if($f_count == 0)
				$contact->Notes= new RNCPHP\NoteArray();
			$contact->Notes[$f_count] = new RNCPHP\Note();
			//$contact->Notes[$f_count]->Channel = new RNCPHP\NamedIDLabel();
			//$contact->Notes[$f_count]->Channel->LookupName = "Phone";
			$contact->Notes[$f_count]->Text = "SMS OPT OUT";			
		}
		$contact->save(RNCPHP\RNObject::SuppressAll);		
	}
	catch ( RNCPHP\ConnectAPIErrorBase $e )
	{
		errorLog("Error in updateContact for Contact ID: ".$contact.". Error is: ". $e->getMessage() );
	}
	catch(Exception $e ) {
		errorLog( "Error in updateContact for Contact ID: ".$contact.". Error is: ".$e->getMessage() );
	}
}	
/*
Send SMS response based on user response to MT SMS. 
Determine the SMS content based on user language preference
*/
function sendSMS($mNum, $mNetwork, $lang, $template)
{
	try
	{
		$url = RNCPHP\Configuration::fetch(CUSTOM_CFG_SMS_API_URL)->Value;
		$shortCode = RNCPHP\Configuration::fetch(CUSTOM_CFG_SMS_API_SHORTCODE)->Value;
		
		//Get the SMS content
		$query = "SELECT ".$lang." as data FROM Config.EmailSmsTemplate WHERE TemplateLabel = '".$template."'";
		$content = RNCPHP\ROQL::query($query)->next()->next();

		load_curl();
		$curl = curl_init();
		$xml = '<?xml version="1.0" encoding="UTF-8"?><xiamSMS>
			<submitRequest id="">
			<from>'.$shortCode.'</from>
			<to>'.$mNum.'</to>
			<content type="text">'.htmlspecialchars($content["data"], ENT_XML1, 'UTF-8').'</content>
			<sendOnGroup value="'.$mNetwork.'"/>
			</submitRequest>
			</xiamSMS>';
			
		$headers = array(
			"Content-type: text/xml",
			"Content-length: " . strlen($xml),
			"Connection: close",
		);
		
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);	
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			
		$data = curl_exec($ch); 
		if(curl_getinfo($ch, CURLINFO_HTTP_CODE) == 200)
		{
				errorLog("Success: ". curl_getinfo($ch, CURLINFO_HTTP_CODE)." Mobile Network: ".$mNetwork."  mobile num: ".$mNum." content: ".$content["data"]." url:".$url);
		}
		else
		{
			errorLog("Error in sendSMS. Error Code: ". curl_getinfo($ch, CURLINFO_HTTP_CODE)." Mobile Network: ".$mNetwork."  mobile num: ".$mNum." content: ".$content["data"]." url:".$url);
		}
		curl_close($ch);		
		/*$p = xml_parser_create();
		xml_parser_set_option( $p, XML_OPTION_CASE_FOLDING, 0 );
		xml_parser_set_option( $p, XML_OPTION_SKIP_WHITE, 1 );
		xml_parse_into_struct( $p, $data, $tags );
		xml_parser_free( $p );
			
		foreach ($tags as $tag) 
		{
			if( $tag['tag']=="result")
			{
				echo $tag['attributes']['status'];	
				echo $tag['attributes']['sendOnGroup'];
				echo $tag['attributes']['messageId'];
			}	
		}*/				
		
	}
	catch ( RNCPHP\ConnectAPIErrorBase $e )
	{
		errorLog("Error in sendSMS. Error is: ". $e->getMessage() );
	}
	catch(Exception $e ) {
		errorLog( "Error in sendSMS. Error is: ". $e->getMessage() );
	}
}
/*
Log the info and error in tmp folder
*/
function errorLog( $msg )
{
	$DIR = "/tmp/sms_integration_".date("Y-m-d").".log";	// log 
	file_put_contents($DIR,  date("Y-m-d H:i:s").": ".$msg.PHP_EOL, FILE_APPEND); // log
}

?>
