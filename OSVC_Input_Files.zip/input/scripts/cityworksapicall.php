﻿<?php 
require_once( get_cfg_var('doc_root') . '/include/ConnectPHP/Connect_init.phph' );
    require_once('include/init.phph');
    initConnectAPI("heena_RNT","Welcome@2020");
  
// Set up versioned namespace for Connect PHP API						
use RightNow\Connect\v1_4 as RNCPHP;
	use \Custom\Libraries as OSvCLibrary;
	const DEV_MODE = true; // NOTE::::::::::::::::: set it to false when moved to prod instance
	define('CUSTLIBPATH',DEV_MODE ? "/cgi-bin/greatersudbury.cfg/scripts/cp/customer/development/" :"/cgi-bin/greatersudbury.cfg/scripts/cp/generated/production/optimized/");					

try
{
	/* $context = RNCPHP\ConnectAPI::getCurrentContext();
	$context->ApplicationContext = "Get Config Values";	
	$base_url=RNCPHP\Configuration::fetch(CUSTOM_CFG_CITYWORKS_DEV_URL)->Value;
	$username=RNCPHP\Configuration::fetch(CUSTOM_CFG_CITYWORKS_DEV_USERNAME)->Value;
	$password=RNCPHP\Configuration::fetch(CUSTOM_CFG_CITYWORKS_DEV_PASSWORD)->Value;	
	
	$url = $base_url."General/Authentication/Authenticate?data="; 
    $payload = array("LoginName" => $username,"Password" => $password,"Expires" => null);
    $json_payload = json_encode($payload);    
    $header =  array(
             "cache-control: no-cache",
			"content-type: application/json"					
        );
		
		if ( !function_exists( "\curl_init" ) )
		{
		   \load_curl();
		}
		$curl_url=$url.$json_payload;
		//echo $curl_url; exit;
		$request = curl_init();	
		curl_setopt($request, CURLOPT_URL, $curl_url );
		curl_setopt($request, CURLOPT_CUSTOMREQUEST, "GET");		
		curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($request, CURLOPT_HEADER, false);
		curl_setopt($request, CURLOPT_ENCODING, "");
		curl_setopt($request, CURLOPT_MAXREDIRS, 10);
		curl_setopt($request, CURLOPT_TIMEOUT,100);
		curl_setopt($request, CURLOPT_HTTP_VERSION , CURL_HTTP_VERSION_1_1);
		curl_setopt($request, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($request, CURLOPT_HTTPHEADER, $header);	
		$response = curl_exec($request);	
		if (FALSE === $response)
			print_r(curl_error($request));		
		curl_close($request);
		
		$json=json_decode($response);
		$token=$json->Value->Token;
		return $token; */
		
		require_once CUSTLIBPATH . "libraries/IncidentToCityWorksSR.php";
		
		OSvCLibrary\IncidentToCityWorksSR::automationOnUpdate( $run_mode, $action, $obj, $n_cycles );			
}
catch(Exception $error){
	echo $error->getMessage();
}


?>