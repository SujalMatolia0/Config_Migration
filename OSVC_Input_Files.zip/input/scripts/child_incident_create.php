﻿<?php
if (!defined('DOCROOT')) {
    $docroot = get_cfg_var('doc_root');
    define('DOCROOT', $docroot);
}
require_once(get_cfg_var('doc_root') . '/include/ConnectPHP/Connect_init.phph');
require_once('include/init.phph');
initConnectAPI();
use RightNow\Connect\v1_4 as RNCPHP;	

function createChildIncident($incID)
{
	$context = RNCPHP\ConnectAPI::getCurrentContext();
	$context->ApplicationContext = "Create child Incidents";
	
	$pInc = RNCPHP\Incident::fetch($incID);
	$nInc = new RNCPHP\Incident();

	$nInc = mapObjFields($pInc, $nInc);
	$nInc->CustomFields->CO->ParentIncident = $pInc;
	$nInc->save(RNCPHP\RNObject::SuppressAll);
}

/**
* Create a field mapping
* @input parent object, new object of same type
* @return new object
*/
function mapObjFields($pObj, $nObj)
{

  //Out of the box fields that are readonly
  $ootbReadOnlyFields = array("ID",
  "LookupName",
  "CreatedTime",
  "UpdatedTime",
  "CreatedByAccount",
  "UpdatedByAccount",
  "ClosedTime",
  "InitialResponseDueTime",
  "InitialSolutionTime",
  "LastResponseTime",
  "Mailing",
  "MilestoneInstances",
  "ReferenceNumber",
  "ResolutionInterval",
  "ResponseInterval",
  "SmartSenseCustomer",
  "SmartSenseStaff",
  "Source",
  "Threads",
  "FileAttachments"
  );
  
  //Escape field that should not be copied
  $fieldsToBeNull = array("IntegrationLog",
						"schedule_date1",
						"schedule_date2",
						"schedule_date3",
						"schedule_date4",
						"schedule_date5"
						 );
  foreach ($pObj as $key => $value)
  {

    //Ignore OOTB redonly field and field that cannot be nullable
    if(in_array($key, $ootbReadOnlyFields))
      continue;
    if(in_array($key, $fieldsToBeNull))
      continue;

    //Special case
    //CustomFields
    if($key == "CustomFields")
    {

      if($pObj->$key !== NULL)
      {
        foreach ($pObj->$key as $cfKey => $cfValue)
        {
          if($pObj->$key->$cfKey !== NULL)
          {
            foreach ($pObj->$key->$cfKey as $cfCoKey => $cfCoValue)
            {
              if(in_array($cfCoKey, $fieldsToBeNull))
              continue;
              $nObj->$key->$cfKey->$cfCoKey = $pObj->$key->$cfKey->$cfCoKey;
            }
          }
        }
      }
    continue;
    }
    //Incident Standard fields
    if($key == "Queue" )
    {

      if( $pObj->$key !== NULL)
      {
        $nObj->Queue = new RNCPHP\NamedIDLabel();
        $nObj->Queue->LookupName = $pObj->Queue->LookupName;
      }
      continue;
    }
    if($key == "Severity")
    {

      if( $pObj->$key !== NULL)
      {
        $nObj->Severity = new RNCPHP\NamedIDOptList();
        $nObj->Severity->LookupName = $pObj->Severity->LookupName;
      }
      continue;
    }
    if($key == "StatusWithType")
    {

      $nObj->StatusWithType = new RNCPHP\StatusWithType() ;
      $nObj->StatusWithType->Status = new RNCPHP\NamedIDOptList() ;
      $nObj->StatusWithType->Status->LookupName = $pObj->StatusWithType->Status->LookupName ;
      continue;
    }
    if($key == "AssignedTo")
    {

      if( $pObj->$key !== NULL)
      {
        $nObj->AssignedTo = new RNCPHP\GroupAccount();
        $nObj->AssignedTo->Account =  $pObj->AssignedTo->Account;
      }
      continue;
    }
    if($key == "Banner")
    {

      if( $pObj->$key !== NULL)
      {
        $nObj->Banner = new RNCPHP\Banner();
        $nObj->Banner->Text = $pObj->Banner->Text;
        $nObj->Banner->ImportanceFlag = $pObj->Banner->Text;
      }
      continue;
    }

    //In general
    //
    if($pObj->$key){
      $nObj->$key = $pObj->$key;
    }
  }

  return $nObj;
}

?>
