﻿<?
// Duplicate Incidents

use RightNow\Connect\v1_3 as RNCPHP;
    try
    {
		$id = $_GET["id"];//Incident ID
		$cat_id = $_GET["cat_id"];//Category ID
		$x = $_GET["x"];//X cordinate
		$y = $_GET["y"];//Y cordinate
        $session_id = $_GET['p_id'];//agent Session
        $ts = $_GET['ts'];//timestamp
		$duplicate_incidents = array();
		$queryObject = NULL;
		
		//echo "<pre>";
		//print_r($_GET);
        // Set up and call the AgentAuthenticator
        require_once (get_cfg_var('doc_root') . '/include/services/AgentAuthenticator.phph');

        $account = AgentAuthenticator::authenticateSessionID($session_id);
        if (!isset($account))
        {
            throw new \Exception("Couldn't Authenticate Agent using Session ID");
        }		
		/*query for selecting radius meters and duration minutes from SrDuplication table*/
		if($cat_id != 'null' && $x != 'null' && $y != 'null'){
			$query = "SELECT radius_meters, duration_minutes, CS.AlternateCategory.id as alternate_category FROM Config.SrDuplication CS WHERE CS.Category.id = ".$cat_id;
			
			$queryObject = RNCPHP\ROQL::query($query)->next(); 
			
			while ($row = $queryObject->next()){
				// The following ensures that if alternate category is not set we use the category that it is.
				// This way if all you want to do is check for direct category duplicates, you can leave that field
				// blank.
				$lookup_cat_id = $row['alternate_category'] != null ? (int)$row['alternate_category'] : $cat_id;
				
				findDuplicates($row, $duplicate_incidents, $lookup_cat_id, $id, $x, $y);
				
			}
		}			
		
		
 
    }
    catch(\Exception $e)
    {
         errorLog($e->getMessage());
    }
    catch (RNCPHP\ConnectAPIErrorBase $e) {
    	errorLog($e->getMessage());
	}
	
	function errorLog( $msg )
	{
    	$DIR = "/tmp/duplicate_incident_".date("Y-m-d").".log";	// log 
    	file_put_contents($DIR,  date("Y-m-d H:i:s").": ".$msg.PHP_EOL, FILE_APPEND); // log
	}
	
	function findDuplicates(&$row, &$duplicate_incidents, $cat_id, $id, $x, $y)
	{
		
		if($row){
			$radius_meters = (int)$row['radius_meters'];
			$duration_minutes = (int)$row['duration_minutes'];
			
			//echo $radius_meters."  :: ".$duration_minutes;
			
			if($x != NULL && $x != '')
			{
				$tmp_x = (int)$x;
				$x_max = ($tmp_x < 0) ? $tmp_x - $radius_meters : $tmp_x + $radius_meters;
				$x_min = ($tmp_x < 0) ? $tmp_x + $radius_meters : $tmp_x - $radius_meters;
			}
			//echo $x_max."  :: ".$x_min;
			if($y != NULL && $y != '')
			{
				$tmp_y = (int)$y;
				$y_max = ($tmp_y < 0) ? $tmp_y - $radius_meters : $tmp_y + $radius_meters;
				$y_min = ($tmp_y < 0) ? $tmp_y + $radius_meters : $tmp_y - $radius_meters;
			}
			//echo $x_max."  :: ".$x_min." :: ".$y_max."  : ".$y_min;
			
			$timetoreduce = -1*abs($duration_minutes);
			$currentdate = date("Y/m/d H:i:s", strtotime("now"));
			
			$datetime = date("Y/m/d H:i:s", strtotime("$timetoreduce minutes"));
			$datetime = strtotime($datetime);
			date_default_timezone_set("America/New_York");
			$date = date("Y-m-d\TH:i:s", $datetime);
			
			$query = "SELECT ID, ReferenceNumber, CustomFields.c.incident_location, StatusWithType.Status.Name as Status, CreatedTime , PrimaryContact.contact.Name as ContactName FROM Incident WHERE  CustomFields.c.duplicate_incident_flag IS NULL AND StatusWithType.Status.Name != 'Closed' AND Category.id = ".$cat_id;
			if($id != 'New' )
			{
				$query .= " AND ID != ".(int)$id;
			}
			
			if($radius_meters == 0 && $duration_minutes == 0)
			{				
				$query .= " AND CustomFields.c.x_coordinate_external ='".$x."' AND CustomFields.c.y_coordinate_external = '".$y."'";
			}
			else if($radius_meters == 0 && $duration_minutes != 0)
			{				
				$query .= " AND CustomFields.c.x_coordinate_external ='".$x."' AND CustomFields.c.y_coordinate_external = '".$y."' AND Incident.CreatedTime >= '".$date."'";
			}
			else if($radius_meters != 0 && $duration_minutes == 0)
			{
				$query .= " AND CustomFields.c.x_coordinate_external < '".$x_max."' AND CustomFields.c.x_coordinate_external > '".$x_min."'AND CustomFields.c.y_coordinate_external < '".$y_max."' AND CustomFields.c.y_coordinate_external > '".$y_min."'";
			}
			else
			{
				$query .= " AND CustomFields.c.x_coordinate_external < '".$x_max."' AND CustomFields.c.x_coordinate_external > '".$x_min."'AND CustomFields.c.y_coordinate_external < '".$y_max."' AND CustomFields.c.y_coordinate_external > '".$y_min."' AND CreatedTime >= '".$date."'";
			}
			
			errorLog("Query for duplicate Incident: ".$query);
			if($query){
				$results = RNCPHP\ROQL::query($query)->next();
				while($result = $results->next())
				{
					$duplicate_incidents[] = $result;
				}
			}
		}
	}

?>
<!DOCTYPE html> <meta http-equiv="X-UA-Compatible" content="IE=Edge" ><!--[if lte IE 8]>
<script src="html5.js" type="text/javascript"></script>
<![endif]-->
 <head>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Datatable library -->
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">  
		<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>

        <!-- FontAwesome for notification and datatable icons -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    </head>
    <body>

		<div id="thumbnail_sr_sa_files">		
			<table id="thumbnail_id">
				<thead>
					<tr>
						<th>Ref Num</th>
						<th>Contact</th>
						<th>Status</th>
						<th>Location</th>
						<th>Created Date</th>
						<th>Attach Duplicate Case</th>
					</tr>
				</thead>
				<tbody id="thumbnail_id_body">
				</tbody>
			</table>			
		</div>

    </body>
<script>
	var duplicateIncidents = <?php echo json_encode($duplicate_incidents); ?>;
	var cat_id = <?php echo json_encode($cat_id); ?>;
	var x = <?php echo json_encode($x); ?>;
	var y = <?php echo json_encode($y); ?>;
	var ts = <?php echo json_encode($ts); ?>;
		

	if(duplicateIncidents != null && duplicateIncidents.length > 0)
	{
		if(ts != null)
			alert("Duplicate Incidents exist for the same category at the same location.");	
		var table = document.getElementById("thumbnail_id");
		duplicateIncidents.forEach(function(duplicateIncident){
			//create new row
			var tableLength = table.length;
			var row = table.getElementsByTagName('tbody')[0].insertRow(tableLength);					
			
			var cell1 = row.insertCell(0);
			var cell2 = row.insertCell(1);
			var cell3 = row.insertCell(2);
			var cell4 = row.insertCell(3);
			var cell5 = row.insertCell(4);
			var cell6 = row.insertCell(5);

			cell1.innerHTML = "<a href='#' onclick='openIncident("+duplicateIncident.ID+")'>"+duplicateIncident.ReferenceNumber+"</a>";
			cell2.innerHTML = duplicateIncident.ContactName;
			cell3.innerHTML = duplicateIncident.Status;
			cell4.innerHTML = duplicateIncident.incident_location;
			cell5.innerHTML = duplicateIncident.CreatedTime;
			cell6.innerHTML = "<input type='checkbox' class ='incIDs' id='"+duplicateIncident.ID+"' />";
			
			
		});
	}
	$('#thumbnail_id').DataTable( {
		"paging":   false,
		"ordering": false,
		"info":     false,
		"bFilter": false,
		"columnDefs": [{"className": "dt-center", "targets": "_all"}]
	} );

	//Binf click event on checkbox
	$('.incIDs').click(function() {
		var checked = this.checked;		
		if (checked) {
			$("input[type=checkbox]").prop("checked", false);//clear all other checkbox
			this.checked = true; 
			setSR(this.id);
		}
		else {
			resetSR();
		}
	});
	
	var i = window.external.Incident;
	//If opened through Destop Console then use Javascript Extension
	if(i !== undefined)
	{
		var css = 'label {font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif !important;display: block !important;font-size: 18px !important;font-weight: normal !important; margin-bottom: 0.25em !important;}.col-md-6 {margin-bottom: 0.2em !important;}.form-control {height: 42px !important;font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif !important;font-size: 18px !important;font-weight: normal !important;}',
	    head = document.head || document.getElementsByTagName('head')[0],
	    style = document.createElement('style');
		head.appendChild(style);	
		style.type = 'text/css';
		style.appendChild(document.createTextNode(css));		
		
		if(duplicateIncidents != null && duplicateIncidents.length > 0)
		{
			i.SetCustomFieldByName('c$duplicate_incident_flag', 1);
		}

		//Function to capture field change, if Category is changed then refesh the page by passing new category ID
		function ondataupdated(changed_object)
		{
			var reload = false;			
			
			if(cat_id != i.Category.split(",")[1])
			{
				reload = true;
				cat_id = i.Category.split(",")[1];
			}
			if(x != i.GetCustomFieldByName("c$x_coordinate_external"))
			{
				reload = true;
				x = i.GetCustomFieldByName("c$x_coordinate_external");
			}
			if(y != i.GetCustomFieldByName("c$y_coordinate_external"))
			{
				reload = true;
				y = i.GetCustomFieldByName("c$y_coordinate_external");	
			}			
			
			if(reload)
			{
				i.SetCustomFieldByName('c$duplicate_incident_flag', 0);//unset the flag

				var d = new Date();
				var timeMs = d.getTime();
				var theUrl = window.location.href;
				theUrl = theUrl.split("&x=")[0]+"&x="+x+"&y="+y+"&cat_id="+cat_id+"&ts=" + timeMs;
				window.location.href = theUrl;
			}			
		}	
		
		function openSR(id)
		{
			alert("Please use quick search to open the SR");
		}

	}
	else
	{
		var css = 'label {font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif !important;display: block !important;font-size: 12px !important;font-weight: normal !important; margin-bottom: 0.25em !important;}.col-md-6 {margin-bottom: 0.5em !important;}.form-control {height: 30px !important;font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif !important;    font-size: 12px !important;    font-weight: normal !important;}',
	    head = document.head || document.getElementsByTagName('head')[0],
	    style = document.createElement('style');
		head.appendChild(style);	
		style.type = 'text/css';
		style.appendChild(document.createTextNode(css));
	
		var theWorkspaceRecord;
		var script = document.createElement('script');                
		script.type = 'text/javascript';
		script.async = true;
		script.src = '/AgentWeb/module/extensibility/js/client/core/extension_loader.js';	
		script.onload = function() {
			
			ORACLE_SERVICE_CLOUD.extension_loader.load("customFormExtionsion", "1")
			.then(function(extensionProvider)
			{
				
		        namedLogger = extensionProvider.getLogger('CGS Logger');
		        namedLogger.trace('Load CGS custom Form Extionsion');
		
		    	extensionProvider.registerWorkspaceExtension(function(workspaceRecord)
		    	{

	    			theWorkspaceRecord = workspaceRecord;
					//List of fields to be prefetch
					workspaceRecord.prefetchWorkspaceFields(['Incident.CatId', 'Incident.c$x_coordinate_external', 'Incident.c$y_coordinate_external']);
	    			
					//OOTB Workspace Event
					//workspaceRecord.addRecordSavingListener(dataSavingListenerForSR);
					workspaceRecord.addFieldValueListener('Incident.CatId', fieldValueListener);
					workspaceRecord.addFieldValueListener('Incident.c$x_coordinate_external', fieldValueListener);
					workspaceRecord.addFieldValueListener('Incident.c$y_coordinate_external', fieldValueListener);

	                if(duplicateIncidents != null && duplicateIncidents.length > 0)
	                {
						workspaceRecord.triggerNamedEvent("focusDuplicateTab");
	                }
		    	});
			});
		};	
		document.head.appendChild(script);			
		
		//Function to capture field change, if Category is changed then refesh the page by passing new category ID
		function fieldValueListener(eventParameter)
		{					 	
			if(eventParameter.event.field == "Incident.CatId")
				cat_id = eventParameter.event.value;
			else if(eventParameter.event.field == "Incident.c$x_coordinate_external")
				x = eventParameter.event.value;
			else if(eventParameter.event.field == "Incident.c$y_coordinate_external")
				y = eventParameter.event.value;				
			
			var d = new Date();
			var timeMs = d.getTime();
			var theUrl = window.location.href;
			theUrl = theUrl.split("&x=")[0]+"&x="+x+"&y="+y+"&cat_id="+cat_id+"&ts=" + timeMs;
			window.location.href = theUrl;		
		}
		
		function setSR(id)
		{
			theWorkspaceRecord.updateField('Incident.CO$ParentIncident', id);
			theWorkspaceRecord.updateField('Incident.c$duplicate_incident_flag', 1);//Set the duplicate flag
		}
		function resetSR()
		{
			theWorkspaceRecord.updateField('Incident.CO$ParentIncident', null);
			theWorkspaceRecord.updateField('Incident.c$duplicate_incident_flag', null);//Set the duplicate flag
		}
		function openIncident(id)
		{			
			theWorkspaceRecord.editWorkspaceRecord('Incident',id);
		}
		
		
	}
	
</script>

