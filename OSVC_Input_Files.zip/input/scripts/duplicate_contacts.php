﻿<?

use RightNow\Connect\v1_3 as RNCPHP;
    try
    {
	
		$fName = $_GET["f_name"];
		$lName = $_GET["l_name"];
		$email = $_GET["email"];
		$hPhone = $_GET["h_phone"];
		$mPhone = $_GET["m_phone"];
		$houseNum = $_GET["house_num"];		
		$city = $_GET["city"];
		$streetName = $_GET["street_name"];		
        $session_id = $_GET['p_id'];
		$id = $_GET["id"];//Contact ID

        $ts = $_GET['ts'];//timestamp
		$duplicate_contacts = array();
		$result = NULL;
		
		//echo "<pre>";
		//print_r($_GET);
        // Set up and call the AgentAuthenticator
        require_once (get_cfg_var('doc_root') . '/include/services/AgentAuthenticator.phph');

        $account = AgentAuthenticator::authenticateSessionID($session_id);
        if (!isset($account))
        {
            throw new \Exception("Couldn't Authenticate Agent using Session ID");
        }		
		
		/*query for fetching duplicate contacts*/
		$query = "SELECT ID, Name.First, Name.Last, Emails.EmailList.Address, Phones.RawNumber, Phones.PhoneType.LookupName AS PhoneType, CustomFields.CO.HouseNumber,CustomFields.CO.StreetName, CustomFields.CO.City FROM Contact WHERE ";
		
		$executeQuery = false;
		if($id != 'New' )//If its existing record
		{
			$query .= "ID != ".(int)$id." AND (";
		}		
		if($fName != 'null' && $lName != 'null'){
			$query .= "(Name.First = '".$fName."' AND Name.Last = '".$lName."') OR " ; 
			$executeQuery = true;
		}	
		if($email != 'null'){
			$query .= "(Emails.Address = '".$email."') OR " ; 
			$executeQuery = true;
		}
		if($hPhone != 'null'){
			$query .= "(Phones.PhoneList.Rawnumber ='".$hPhone."' AND phones.phonelist.phonetype.lookupname ='Home Phone') OR " ; 
			$executeQuery = true;
		}
		if($mPhone != 'null'){
			$query .= "( Phones.PhoneList.Rawnumber = '".$mPhone."' AND phones.phonelist.phonetype.lookupname ='Mobile Phone') OR " ; 
			$executeQuery = true;
		}
		if($houseNum != 'null' && $streetName != 'null' && $city != 'null'){
			$query .= "(CustomFields.CO.HouseNumber = '".$houseNum."' AND CustomFields.CO.StreetName = '".$streetName."' AND CustomFields.CO.City = '".$city."') OR " ; 
			$executeQuery = true;
		}	
	
		if($id != 'New' )//If its existing record
			$query = preg_replace('/ OR $/', ')', $query);
		else
			$query = preg_replace('/ OR $/', '', $query);
		

		//echo $query;
		if($executeQuery){
			$results = RNCPHP\ROQL::query($query)->next();
			while($result = $results->next())
			{
				if($duplicate_contacts[$result['ID']])
				{
					if($result['PhoneType'] == 'Mobile Phone')
						$duplicate_contacts[$result['ID']]['MobileNum'] = $result['RawNumber'];
					if($result['PhoneType'] == 'Home Phone')
						$duplicate_contacts[$result['ID']]['HomeNum'] = $result['RawNumber'];				
				}
				else
					$duplicate_contacts[$result['ID']] = $result;
			}
		} 



		if(isset($id) && $id != 'New' && isset($fName) && $fName != "null") {
			
			 $pds = array();  //Disabled != 1 AND <<< put back in after testing
			 $q = "SELECT Distinct ID FROM Contact WHERE  ID != "
			 .$id." AND ((Name.First = '".$fName
			 ."' AND Name.Last = '".$lName."')";
			 if($email != 'null'){$q.=" OR Emails.Address = '".$email."'";}
			 if($hPhone != 'null'){$q.=" OR Phones.Number = '".$hPhone."'";}
			 if($mPhone != 'null'){$q.=" OR Phones.Number = '".$mPhone."'";}
			 if($houseNum != 'null' && $streetName != 'null' && $city != 'null'){
				 $q.=" OR (CustomFields.CO.HouseNumber = '".$houseNum
				 ."' AND CustomFields.CO.StreetName = '".$streetName 
				 ."' AND CustomFields.CO.City = '".$city."')";
			 }
			 $q.=")";

			 $c2Res = RNCPHP\ROQL::query($q)->next();
			 
			 while ($c2 = $c2Res->next()) { 
				 //if(!empty($c2['Address']) && !empty($c2['Number']))
				 $pds[] = $c2['ID']; 
			 }
			 $pdRes = RNCPHP\ROQL::query("SELECT ID,IsDuplicate,Contact1,Contact2 FROM CO.PotentialDuplicate WHERE Contact1 = "
			 .$id. " OR Contact2 = " .$id)->next();
			 while ($pd = $pdRes->next()) {
					 foreach($pds as $p => $v) {
					 if($v == $pd['Contact1'] || $v == $pd['Contact2']) {
						 unset($pds[$p]);
					 }
				 }
			 }
			 foreach ($pds as $pd) {
					 $pdr = new RNCPHP\CO\PotentialDuplicate();
					 $pdr->Contact1 = RNCPHP\Contact::fetch(intval($id));
					 $pdr->Contact2 = RNCPHP\Contact::fetch(intval($pd));
					 $pdr->save();
			 }
			 $de = false; $q = "SELECT ID FROM CO.PotentialDuplicate WHERE IsDuplicate Is Null And (Contact1 = ".$id. " OR Contact2 = " .$id.")";
			 $pd2Res = RNCPHP\ROQL::query($q)->next();while ($pd = $pd2Res->next()) { $de=true; } if(!$de) {$duplicate_contacts = null;}
		   }
    }
    catch(\Exception $ex)
    {
         echo  $ex->getMessage();
    }
    catch (RNCPHP\ConnectAPIErrorBase $e) {
    	echo $e->getMessage();
	}

	



?>
<!DOCTYPE html> <meta http-equiv="X-UA-Compatible" content="IE=Edge" ><!--[if lte IE 8]>
<script src="html5.js" type="text/javascript"></script>
<![endif]-->
 <head>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Datatable library -->
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">  
		<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>

        <!-- FontAwesome for notification and datatable icons -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    </head>
    <body>

		<div id="thumbnail_sr_sa_files">		
		<p style="color: red;font-size: 24px;width: 250px;margin: auto;/* margin-left: 40%; */"> Duplicate Contacts found </p>
			<table id="thumbnail_id">
				<thead>
					<tr>
						<th>First Name</th>
						<th>Last Name</th>
						<th>Email</th>
						<th>Home #</th>
						<th>Mobile #</th>
						<th>House Num</th>
						<th>Street Name</th>
						<th>City</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="thumbnail_id_body">
				</tbody>
			</table>			
		</div>

    </body>
<script>
	var duplicateContacts = <?php echo json_encode($duplicate_contacts); ?>;

	if( !Array.isArray(duplicateContacts) && duplicateContacts != null)
	{
		alert("Potential Duplicate Contact Detected");	
		var table = document.getElementById("thumbnail_id");
		
		for (var key in duplicateContacts) {
			var tableLength = table.length;
			var row = table.getElementsByTagName('tbody')[0].insertRow(tableLength);					
			
			var cell1 = row.insertCell(0);
			var cell2 = row.insertCell(1);
			var cell3 = row.insertCell(2);
			var cell4 = row.insertCell(3);
			var cell5 = row.insertCell(4);
			var cell6 = row.insertCell(5);
			var cell7 = row.insertCell(6);
			var cell8 = row.insertCell(7);	
			var cell9 = row.insertCell(8);			
			//console.log(duplicateContacts[key]);
			cell1.innerHTML = duplicateContacts[key].First;
			cell2.innerHTML = duplicateContacts[key].Last;
			cell3.innerHTML = duplicateContacts[key].Address;
			cell4.innerHTML = duplicateContacts[key].HomeNum;
			cell5.innerHTML = duplicateContacts[key].MobileNum;
			cell6.innerHTML = duplicateContacts[key].HouseNumber;
			cell7.innerHTML = duplicateContacts[key].StreetName;
			cell8.innerHTML = duplicateContacts[key].City;	
			cell9.innerHTML = "<a href='#' onclick='openContact("+duplicateContacts[key].ID+");' id='"+duplicateContacts[key].ID+"' >Select</a>";			
		}
	}
	$('#thumbnail_id').DataTable( {
		"paging":   false,
		"ordering": false,
		"info":     false,
		"bFilter": false,
		"columnDefs": [{"className": "dt-center", "targets": "_all"}]
	} );

	var i = window.external.Incident;
	//If opened through Destop Console then use Javascript Extension
	if(i !== undefined)
	{
	

	}
	else
	{
		var css = 'label {font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif !important;display: block !important;font-size: 12px !important;font-weight: normal !important; margin-bottom: 0.25em !important;}.col-md-6 {margin-bottom: 0.5em !important;}.form-control {height: 30px !important;font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif !important;    font-size: 12px !important;    font-weight: normal !important;}',
	    head = document.head || document.getElementsByTagName('head')[0],
	    style = document.createElement('style');
		head.appendChild(style);	
		style.type = 'text/css';
		style.appendChild(document.createTextNode(css));
	
		var wsRecord;
		var script = document.createElement('script');                
		script.type = 'text/javascript';
		script.async = true;
		script.src = '/AgentWeb/module/extensibility/js/client/core/extension_loader.js';	
		script.onload = function() {
			
			ORACLE_SERVICE_CLOUD.extension_loader.load("customFormExtionsion", "1")
			.then(function(extensionProvider)
			{				
		        namedLogger = extensionProvider.getLogger('CGS Logger');
		        namedLogger.trace('Load CGS custom Form Extionsion');
		
		    	extensionProvider.registerWorkspaceExtension(function(workspaceRecord)
		    	{
	    			wsRecord = workspaceRecord;
					//List of fields to be prefetch
					wsRecord.prefetchWorkspaceFields(['Contact.Name.First','Contact.Name.Last','Contact.Email.Addr','Contact.PhHome','Contact.PhMobile','Contact.CO$HouseNumber','Contact.CO$StreetName','Contact.CO$City']);
	    			
					//OOTB Workspace Event
					//workspaceRecord.addRecordSavingListener(dataSavingListenerForSR);
					wsRecord.addFieldValueListener('Contact.Name.First', fieldValueListener);
					wsRecord.addFieldValueListener('Contact.Name.Last', fieldValueListener);
					wsRecord.addFieldValueListener('Contact.Email.Addr', fieldValueListener);
					wsRecord.addFieldValueListener('Contact.PhHome', fieldValueListener);
					wsRecord.addFieldValueListener('Contact.PhMobile', fieldValueListener);
					wsRecord.addFieldValueListener('Contact.CO$HouseNumber', fieldValueListener);wsRecord.addFieldValueListener('Contact.CO$StreetName', fieldValueListener);
					wsRecord.addFieldValueListener('Contact.CO$City', fieldValueListener);
					
					if( !Array.isArray(duplicateContacts) && duplicateContacts != null)
					{
						wsRecord.triggerNamedEvent("focusDuplicateTab");
					}
					else
					{
						wsRecord.triggerNamedEvent("hideDuplicateTab");
					}

		    	});
			});
		};	
		document.head.appendChild(script);			
		
		//Function to capture field change, if Category is changed then refesh the page by passing new category ID
		function fieldValueListener(eventParameter)
		{
			let fName, lName, email, hPhone, mPhone, hNum, street, city;

			if(eventParameter.event.fieldObjects["Contact.Name.First"].value != null)
				fName = eventParameter.event.fieldObjects["Contact.Name.First"].value;
			if(eventParameter.event.fieldObjects["Contact.Name.First"].value != null)
				lName = eventParameter.event.fieldObjects["Contact.Name.Last"].value;			
			if(eventParameter.event.fieldObjects["Contact.Email.Addr"].value != null)
				email = eventParameter.event.fieldObjects["Contact.Email.Addr"].value;	
			if(eventParameter.event.fieldObjects["Contact.PhHome"].value != null)
				hPhone = eventParameter.event.fieldObjects["Contact.PhHome"].value;
			if(eventParameter.event.fieldObjects["Contact.PhMobile"].value != null)
				mPhone = eventParameter.event.fieldObjects["Contact.PhMobile"].value;
			if(eventParameter.event.fieldObjects["Contact.CO$HouseNumber"].value != null)
				hNum = eventParameter.event.fieldObjects["Contact.CO$HouseNumber"].value;
			if(eventParameter.event.fieldObjects["Contact.CO$StreetName"].value != null)
				street = eventParameter.event.fieldObjects["Contact.CO$StreetName"].value;
			if(eventParameter.event.fieldObjects["Contact.CO$City"].value != null)
				city = eventParameter.event.fieldObjects["Contact.CO$City"].value;			
			
			var d = new Date();
			var timeMs = d.getTime();
			var theUrl = window.location.href;
			theUrl = theUrl.split("&f_name=")[0]+"&f_name="+fName+"&l_name="+lName+"&email="+email+"&h_phone="+hPhone+"&m_phone="+mPhone+"&house_num="+hNum+"&street_name="+street+"&city="+city+"&ts=" + timeMs;
			window.location.href = theUrl;
		}
		
		function openContact(id)
		{
			
			wsRecord.closeEditor().then(function (workspaceOperationParameter) {
				console.log(workspaceOperationParameter);		
			}).catch(function (error) {
				console.log(error);
			});		
			wsRecord.editWorkspaceRecord('Contact',id);
		}
	}
	
</script>

