# ---------------------------------------------------------------------------
# OSVC Field Extractor - Connection Configuration
# ---------------------------------------------------------------------------

BASE_URL  = "https://gcb.custhelp.com/services/rest/connect/v1.4/metadata-catalog/contacts"
USERNAME  = "gcbosc"
PASSWORD  = "5tgb%TGB5tgb%TGB"
