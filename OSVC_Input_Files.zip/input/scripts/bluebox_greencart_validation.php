﻿<?
use RightNow\Connect\v1_3 as RNCPHP;
    try
    {
        $session_id = $_GET['p_id'];//agent Session
        $address = $_GET['address'];//address
		$cat_id = $_GET['cat_id'];//address
        // Set up and call the AgentAuthenticator
        require_once (get_cfg_var('doc_root') . '/include/services/AgentAuthenticator.phph');

        $account = AgentAuthenticator::authenticateSessionID($session_id);
        if (!isset($account))
        {
            throw new \Exception("Couldn't Authenticate Agent using Session ID");
        }		
    }
    catch(\Exception $ex)
    {
         echo  $ex->getMessage();
    }
    catch (RNCPHP\ConnectAPIErrorBase $e) {
    	echo $e->getMessage();
	}
?>
<!DOCTYPE html> 
<meta http-equiv="X-UA-Compatible" content="IE=Edge" >
 <head>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>

<script>
	var p_id = <?php echo json_encode($session_id); ?>;
	var address = <?php echo json_encode($address); ?>;
	var cat_id = <?php echo json_encode($cat_id); ?>;

	/*
	call the fucntion to check the address in OSvC BlueBoxGreenCartAddr config object through REST API
	*/
	function validateAddress(triggeredBy)
	{
		var contractor = "";// default Contractor  name
		if(address != 'null' && address != '')//ex: 23 A Stanyon Street, Sudbury
		{
			let adrInfo = address.trim().split(",");
			let city = adrInfo[1].trim();//ex: Sudbury
			let streetInfo = adrInfo[0].trim().split(" ");
			let streetNum = streetInfo[0].trim();// ex: "23"
			let streetName = "";
			let modifiedStreetName = "";
			let fstWordOfStreet = "";
			if(typeof streetInfo[1] === 'number' || streetInfo[1].length == 1)//Check if unit number if provided, it will either in interger or A-Z
			{
				streetNum = streetNum +" "+streetInfo[1].trim();
				fstWordOfStreet = streetInfo[2];
				streetName = streetInfo.slice(2, streetInfo.length).join(" ");
				modifiedStreetName = streetInfo.slice(3, streetInfo.length).join(" ");//leave the first word of actual street name
				
			}
			else
			{
				streetName = streetInfo.slice(1, streetInfo.length).join(" ");
				fstWordOfStreet = streetInfo[1];
				modifiedStreetName = streetInfo.slice(2, streetInfo.length).join(" ");//leave the first word of actual street name
			}

			//streetName = streetName.substring(0, streetName.lastIndexOf(" "));// remove last st with %
			
			//There is a mismatch in street name between what we get from ESRI and what's in OSvC config object
			//So replace below road name suffix with abbreviations
			var streetsSuffix = {
				'Road':'RD',
				'Street':'ST',
				'Place':'PL',
				'Crescent':'CRES',
				'Court':'CRT',
				'Drive':'DR',
				'Avenue':'AVE',				
				'Boulevard':'BLVD',
				'Circle':'CIR',
				'Expressway':'EXPY',
				'Freeway':'FWY',
				'Lane':'LN',
				'Parkway':'PKY',
				'Square':'SQ',
				'Turnpike':'TPKE',				
				'North':'N',
				'East':'E',
				'South':'S',
				'West':'W',
				'Northeast':'NE',
				'Southeast':'SE',
				'Southwest':'SW',
				'Northwest':'NW'
			};			


			for (var key in streetsSuffix ) {
				//var re = new RegExp(key, 'gi');
				var re = new RegExp("\\b(?:" + key + ")\\b","g");
				modifiedStreetName = modifiedStreetName.replace(re, streetsSuffix[key]);
			}	
			
			modifiedStreetName = fstWordOfStreet+" "+modifiedStreetName;
			//REST API URL + Query string...NOTE: not passing street number on where clause as street number can be in range like 4-8 or 2a-2f. So not possible to apply that in where clause
			var url = "/services/rest/connect/latest/queryResults/?query=SELECT StreetNumber, Contractor FROM Config.BlueBoxGreenCartAddr WHERE BinRequest = 1 AND ( StreetName = '"+streetName.replace("'", "''")+"' OR StreetName = '"+modifiedStreetName.replace("'", "''")+"' ) AND CommunityName = '"+city+"'";
			
			var xhr = new XMLHttpRequest();
			xhr.open('GET', url, false);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.setRequestHeader('OSvC-CREST-Application-Context', 'Sudbury Address Validation');
			xhr.setRequestHeader('Authorization', 'Session ' + p_id);
			xhr.onload = function() {
				if (xhr.status === 200)
				{									
					var output = [];
					JSON.parse(xhr.responseText).items[0].rows.forEach(function(row)
					{
						let osvcStNum = row[0].trim();
						osvcStNum = osvcStNum.replace(/ +(?= )/g,'');// replace multi space with single
						//Parse the street number to make sure address match
						if(streetNum == osvcStNum)
						{
							contractor = row[1];
							//adrValidationFlag = true;
							//break;
						}
						/*else if(osvcStNum.indexOf('-') !== -1)//if street num contains - that is range
						{
							var tmp = row[0].split("-");
							if(streetNum >= tmp[0].trim() && streetNum <= tmp[1].trim())
							{
								contractor = row[1];
								//adrValidationFlag = true;
								//break;
							}
						}	*/
					});											
				}
				else if (xhr.status !== 200) 
				{
				}
			};
			xhr.send();
		}
		if(contractor == "")
			alert("The address does not seem eligible to receive blue box(es) and green cart(s).");
		else
		{
			if (typeof setContractor === "function")
				setContractor(contractor);
			if(triggeredBy == 'manually')
				alert("The address is eligible to receive blue box(es) and green cart(s).");
		}
		return contractor;
	}
	
	var i = window.external.Incident;
	//If opened through Destop Console then use Javascript Extension
	if(i !== undefined)
	{	
		function onbeforesave()
		{
			if (cat_id == 36 && typeof validateAddress === "function")
			{			
				if(validateAddress('auto') == "")
				{				
					window.external.beforesavecomplete(false, "The address does not seem eligible to receive blue box(es) and green cart(s).");
				}		
			}
		}
		//Function to capture field change, if Category is changed then refesh the page by passing new category ID
		function ondataupdated(changed_object)
		{
			if(cat_id != i.Category.split(",")[1])
			{
				cat_id = i.Category.split(",")[1];
			}

			if(address != i.GetCustomFieldByName("c$incident_location"))
			{
				reload = true;
				address = i.GetCustomFieldByName("c$incident_location");	
			}		
		}	
		
		function setContractor(contractor)
		{
			i.SetCustomFieldByName("c$bb_gc_contractor",contractor);
		}

	}
	else
	{
		var theWorkspaceRecord;
		var script = document.createElement('script');                
		script.type = 'text/javascript';
		script.async = true;
		script.src = '/AgentWeb/module/extensibility/js/client/core/extension_loader.js';	
		script.onload = function() {
			
			ORACLE_SERVICE_CLOUD.extension_loader.load("customFormExtionsion", "1")
			.then(function(extensionProvider)
			{			
		        namedLogger = extensionProvider.getLogger('CGS Logger');
		        namedLogger.trace('Load CGS custom Form Extionsion');
		
		    	extensionProvider.registerWorkspaceExtension(function(workspaceRecord)
		    	{
	    			theWorkspaceRecord = workspaceRecord;
					workspaceRecord.prefetchWorkspaceFields(['Incident.CatId','Incident.c$incident_location','Incident.c$fcr','Incident.c$override_bb_gc_validation']);
					//OOTB Workspace Event
					workspaceRecord.addFieldValueListener('Incident.CatId', fieldValueListener);
					workspaceRecord.addFieldValueListener('Incident.c$incident_location', fieldValueListener);
					workspaceRecord.addRecordSavingListener(dataSavingListenerForSR);
		    	});
			});
		}
		document.head.appendChild(script);
		//Function to call address validation on save operation of Incident
		//If address validation fails then cancel the save operation		
		function dataSavingListenerForSR(parameter) 
		{		
			//Ignore if FCR is set or if override_bb_gc_validation flag is set
			if((parameter.event.fieldObjects["Incident.c$fcr"] && parameter.event.fieldObjects["Incident.c$fcr"].value == 1)
				|| (parameter.event.fieldObjects["Incident.c$override_bb_gc_validation"] && parameter.event.fieldObjects["Incident.c$override_bb_gc_validation"].value == 1)
			  )
				return;
			
			if (cat_id == 36 && typeof validateAddress === "function")
			{
				if(validateAddress('auto') == "")
				{				
					parameter.getCurrentEvent().cancel();					
				}	
				
			}	
		}	
		
		//Function to capture field change
		function fieldValueListener(eventParameter)
		{		 	
			if(eventParameter.event.field == "Incident.CatId")
				cat_id = eventParameter.event.value;
			else if(eventParameter.event.field == "Incident.c$incident_location")
				address = eventParameter.event.value;		
		}
		
		function setContractor(contractor)
		{
			theWorkspaceRecord.updateField('Incident.c$bb_gc_contractor', contractor);
		}

	}
	
</script>

    <body>
		<button type="button" onclick="validateAddress('manually')">Address Validation</button>
    </body>