﻿<?php
use RightNow\Connect\v1_3 as RNCPHP;

try
{
    $session_id = $_GET['p_id'];//agent Session
    //$id = 1
    // Set up and call the AgentAuthenticator
    require_once (get_cfg_var('doc_root') . '/include/services/AgentAuthenticator.phph');

    $account = AgentAuthenticator::authenticateSessionID($session_id);
    if (!isset($account))
    {
        throw new \Exception("Couldn't Authenticate Agent using Session ID");
    }	
    $query = "SELECT CO.EventTimer FROM CO.EventTimer ORDER BY EventEndDate DESC LIMIT 1";
    if($query){
        $events = RNCPHP\ROQL::query($query)->next();
        while($event = $events->next())
        {
            $eventDateTime = $event["EventEndDate"];
            //echo "<script type='text/javascript'>alert('$eventID');</script>";
        }
        
    }	
}
catch(\Exception $ex)
{
     echo  $ex->getMessage();
}
catch (RNCPHP\ConnectAPIErrorBase $e) {
    echo $e->getMessage();
}

?>
	
<!DOCTYPE html> 
<meta http-equiv="X-UA-Compatible" content="IE=Edge" >
 <head>
 <style>
p {
  text-align: center;
  font-size: 25px;
  margin-top: 0px;
}
h1 {
  text-align: center;
  font-size: 15px;
  margin-top: 0px;
}
h2 {
  text-align: center;
  font-size: 12px;
  margin-top: 0px;
}
</style>
</head>

<body>
<h1 id="title1"></h1>   
<h1 id="title2"></h1>     
<p id="timer"></p>   
<h1 id="title3"><h1>
<h2 id="enddate"></h2> 
<script>

var EndDate = <?php echo json_encode($eventDateTime); ?>;
var addMlSeconds = 86400000;
var CurrentEndDate = new Date(EndDate);
var CurrentEndDateLongString = CurrentEndDate.toString();
var CurrentEndDateShortString = CurrentEndDateLongString.replace("GMT-0500 (Eastern Standard Time)","");

var CurrentEndDateTime = CurrentEndDate.getTime();
var EndDateTime = new Date(CurrentEndDateTime + addMlSeconds);


// Set the date we're counting down to
var countDownDate = EndDateTime.getTime();


// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now; 
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  document.getElementById("title1").innerHTML = "Winter Event Countback Clock";
  document.getElementById("title2").innerHTML = "Time Remaining For Cleanup";
  // Output the result in an element with id="demo"
  document.getElementById("timer").innerHTML =  hours + "h "
  + minutes + "m " + seconds + "s ";
  document.getElementById("title3").innerHTML = "Event Ended On";
  document.getElementById("enddate").innerHTML = CurrentEndDateShortString; 
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("title1").innerHTML = "";
    document.getElementById("title2").innerHTML = "";
    document.getElementById("timer").innerHTML = "";
    document.getElementById("title3").innerHTML = "";
    document.getElementById("enddate").innerHTML = "";
  }
}, 1000);
</script>
</body>
	

